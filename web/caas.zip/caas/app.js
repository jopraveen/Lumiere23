const express = require("express")
const app = express();
const child_process = require("child_process")

app.get('/',(req, res)=>{

  if(req.query.url){
    resp = child_process.execSync(`curl ${req.query.url}`).toString();
    res.send(resp);
  }else{
    temp = `
    <h1>CaaS - Curl as a Service!</h1>
    <form>
    <input id=url placeholder="https://google.com/"><br>
    <button type=button onclick="window.location=\`?url=\${window.url.value}\`">Submit</button>
    </form>
    `
    res.send(temp);
  }

})

app.listen(8080)
